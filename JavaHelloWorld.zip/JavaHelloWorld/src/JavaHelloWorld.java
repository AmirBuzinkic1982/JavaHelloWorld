
public class JavaHelloWorld {

	public static void main(String[] args) {
		 for(int i=0;i<36;i++){

		        System.out.println("Hello World");

	}

	}
}